package com.example.SkarptHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkarptHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkarptHubApplication.class, args);
	}

}
